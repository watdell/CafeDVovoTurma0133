import streamlit as st        
from setup import setup

setup('Vendas')
st.title('TITULO')