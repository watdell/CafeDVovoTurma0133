from setup import setup

setup('Vendas')